from . import layers

custom_objects = {
    'BatchNormalization': layers.BatchNormalization,
}
